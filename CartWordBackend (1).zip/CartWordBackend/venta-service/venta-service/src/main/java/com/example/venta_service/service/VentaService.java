package com.example.venta_service.service;import com.example.venta_service.model.Venta;
import com.example.venta_service.repository.VentaRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;



@Service
public class VentaService {

    private final VentaRepository repo;
    // Volvemos a crear el RestTemplate aquí mismo. Simple y directo.
    private final RestTemplate rest = new RestTemplate();

    public VentaService(VentaRepository repo) {
        this.repo = repo;
    }

    public Venta registrarVenta(Venta venta) {

        // --- INICIO DE LA CORRECCIÓN CLAVE ---
        // Se define la URL completa y directa a tu producto-service
        String urlProducto = "http://localhost:8081/productos/" + venta.getProductId();
        
        ProductoDTO product = rest.getForObject(urlProducto, ProductoDTO.class);
        // --- FIN DE LA CORRECCIÓN CLAVE ---

        if(product == null) {
            throw new RuntimeException("Producto no encontrado con ID: " + venta.getProductId());
        }

        if(product.stock < venta.getCantidad()) {
            throw new RuntimeException("Stock insuficiente para el producto: " + product.nombre);
        }

        // Se resta el stock y se actualiza en el producto-service
        product.stock -= venta.getCantidad();
        String urlActualizarStock = "http://localhost:8081/productos/" + product.id;
        rest.put(urlActualizarStock, product);

        // Se finaliza la venta
        venta.setTotal(product.precio * venta.getCantidad());
        // La fecha se asigna con @PrePersist en tu modelo Venta, así que no es necesaria aquí.
        // venta.setFecha(LocalDateTime.now());

        return repo.save(venta);
    }

    // Clase DTO para recibir los datos del producto
    public static class ProductoDTO {
        public Long id;
        public String nombre;
        public Double precio;
        public Integer stock;
        public String descripcion;
        public String categoria;
        public String imageUrl;
    }
}