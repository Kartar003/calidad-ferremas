package com.example.venta_service.repository;

import com.example.venta_service.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VentaRepository extends JpaRepository<Venta, Long> {
    List<Venta> findByUserId(Long userId);
}
