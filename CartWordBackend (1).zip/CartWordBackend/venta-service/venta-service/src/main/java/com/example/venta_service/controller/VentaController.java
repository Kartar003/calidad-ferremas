package com.example.venta_service.controller;

import com.example.venta_service.model.Venta;
import com.example.venta_service.repository.VentaRepository;
import com.example.venta_service.service.VentaService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/ventas")
@CrossOrigin(origins = "*")
public class VentaController {

    private final VentaService svc;
    private final VentaRepository repo;

    public VentaController(VentaService svc, VentaRepository repo) {
        this.svc = svc;
        this.repo = repo;
    }

    @PostMapping
    public ResponseEntity<?> registrar(@RequestBody Venta v) {
        try {
            return ResponseEntity.ok(svc.registrarVenta(v));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(repo.findAll());
    }

    @GetMapping("/usuario/{id}")
    public ResponseEntity<?> ventasPorUsuario(@PathVariable Long id) {
        return ResponseEntity.ok(repo.findByUserId(id));
    }
}
