package com.example.venta_service.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "ventas")
public class Venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long productId;
    private Integer cantidad;
    private Double total;
    private LocalDateTime fecha;
    @PrePersist
    public void prePersist() {
        fecha = LocalDateTime.now();
    }
}
