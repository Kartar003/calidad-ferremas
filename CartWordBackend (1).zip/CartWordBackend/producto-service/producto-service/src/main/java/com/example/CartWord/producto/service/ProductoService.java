package com.example.CartWord.producto.service;

import com.example.CartWord.producto.model.Producto;
import com.example.CartWord.producto.repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductoService {

    private final ProductoRepository repo;

    public ProductoService(ProductoRepository repo) {
        this.repo = repo;
    }

    public Producto guardar(Producto p) {
        return repo.save(p);
    }

    public List<Producto> listar() {
        return repo.findAll();
    }

    public Producto buscarPorId(Long id) {
        return repo.findById(id).orElse(null);
    }

    public Producto actualizar(Long id, Producto nuevo) {
        return repo.findById(id).map(p -> {
            p.setNombre(nuevo.getNombre());
            p.setDescripcion(nuevo.getDescripcion());
            p.setPrecio(nuevo.getPrecio());
            p.setStock(nuevo.getStock());
            p.setCategoria(nuevo.getCategoria());
            p.setImageUrl(nuevo.getImageUrl());
            return repo.save(p);
        }).orElse(null);
    }

    public boolean eliminar(Long id) {
        if(!repo.existsById(id)) return false;
        repo.deleteById(id);
        return true;
    }
}
